import RoutesToPage from './RoutesToPage'

export default function App() {
  return (
    <div>
        <RoutesToPage/>
    </div>
  )
}
